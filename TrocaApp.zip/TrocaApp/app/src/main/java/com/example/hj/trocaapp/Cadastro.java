package com.example.hj.trocaapp;

import android.os.Bundle;
import android.view.View;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class Cadastro  extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

    }
    public void cadastrar (View view){
//
//        EditText pergunta = (EditText) findViewById(R.id.pergunta);
//        EditText resposta = (EditText) findViewById(R.id.resposta);
//        Toast.makeText(this, "Clicou", Toast.LENGTH_SHORT).show();
//        FirebaseFirestore db = FirebaseFirestore.getInstance();
//        Map<String, Object> trocadilhos = new HashMap<>();
//
//        trocadilhos.put("pergunta", pergunta.getEditableText().toString());
//        trocadilhos.put("resposta", resposta.getEditableText().toString());
//
//        db.collection("trocadilho")
//                .add(trocadilhos)
//                .addOnSuccessListener(new OnSuccessListener<DocumentReference>() {
//                    @Override
//                    public void onSuccess(DocumentReference documentReference) {
//                        Log.i("ok", documentReference.getId());
//                        finish();
//                    }
//                })
//                .addOnFailureListener(new OnFailureListener() {
//                    @Override
//                    public void onFailure(@NonNull Exception e) {
//                        Log.i("Erro", "Não salvou");
//                    }
//                });
    }




}