package com.example.hj.trocaapp;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.HashMap;
import java.util.Map;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

//        FirebaseFirestore db = FirebaseFirestore.getInstance();
//        Map<String, Object> trocadilhos = new HashMap<>();
//
//        trocadilhos.put("pergunta", "piada do pinho");
//        trocadilhos.put("resposta","Piu");
//
//        db.collection("trocadilho")
//                .add(trocadilhos)
//                .addOnSuccessListener(new OnSuccessListener<DocumentReference>() {
//                    @Override
//                    public void onSuccess(DocumentReference documentReference) {
//                        Log.i("ok", documentReference.getId());
//                    }
//                })
//                  .addOnFailureListener(new OnFailureListener() {
//                      @Override
//                      public void onFailure(@NonNull Exception e) {
//                          Log.i("Erro", "Não salvou");
//                      }
//                  });

    }

    public void listar(View view) {
        Toast.makeText(this, "Listar", Toast.LENGTH_SHORT).show();

    }

    public void adicionar(View view) {
        Intent intent = new Intent(this, ListarActivity.class);

    }
}
